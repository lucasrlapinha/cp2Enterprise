﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cp2.Enums
{
    internal enum StatusPedido
    {
        Processando = 1,
        Enviado = 2,
        Concluido = 3,
    }
}
