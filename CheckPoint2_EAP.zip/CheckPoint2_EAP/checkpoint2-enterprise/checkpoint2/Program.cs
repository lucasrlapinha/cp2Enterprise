﻿
using cp2.Enums;
using cp2;
using cp2.Heranca;

int opcao = 0;

List<Produto> produtos = new List<Produto>();
List<Funcionario> funcionarios = new List<Funcionario>();
List<Pedido> pedidos = new List<Pedido>();

do
{

    Console.WriteLine("1 - Cadastrar Produto");
    Console.WriteLine("2 - Cadastrar Funcionário");
    Console.WriteLine("3 - Efetuar Venda");
    Console.WriteLine("4 - Listar Produtos");
    Console.WriteLine("5 - Listar Funcionarios");
    Console.WriteLine("6 - Listar Pedidos");
    Console.WriteLine("7 - Calcular Pagamento de Funcionário");
    Console.WriteLine("8 - Sair");
    Console.Write("Opcao: ");

    opcao = int.Parse(Console.ReadLine());

    Console.Clear();


    switch (opcao)
    {
        case 1:
            Console.WriteLine("Cadastrar Produto");
            Produto produto = new Produto();

            Console.Write("Id: ");
            produto.Id = int.Parse(Console.ReadLine());

            Console.Write("Nome: ");
            produto.Nome = Console.ReadLine();

            Console.Write("Valor: ");
            produto.Valor = double.Parse(Console.ReadLine());

            produtos.Add(produto);
            Console.Clear();
            break;

        case 2:
            Console.WriteLine("Qual é o tipo de funcionário? (V)endedor ou (G)erente");
            string tipoFuncionario = Console.ReadLine();
            if (tipoFuncionario == "V" || tipoFuncionario == "v")
            {
                Vendedor vendedor = new Vendedor();

                Console.Write("Digite o id do Vendedor: ");
                vendedor.Id = int.Parse(Console.ReadLine());

                Console.Write("Nome do Vendedor: ");
                vendedor.Nome = Console.ReadLine();

                Console.Write("Matricula do Vendedor: ");
                vendedor.Matricula = Console.ReadLine();

                Console.Write("Salario do Vendedor: ");
                vendedor.Salario = double.Parse(Console.ReadLine());

                funcionarios.Add(vendedor);
                Console.Clear();
                break;
            }
            else if (tipoFuncionario == "G" || tipoFuncionario == "g")
            {
                Gerente gerente = new Gerente();

                Console.Write("Digite o id do Gerente: ");
                gerente.Id = int.Parse(Console.ReadLine());

                Console.Write("Nome do Gerente: ");
                gerente.Nome = Console.ReadLine();

                Console.Write("Matricula do Gerente: ");
                gerente.Matricula = Console.ReadLine();

                Console.Write("Salario do Gerente: ");
                gerente.Salario = double.Parse(Console.ReadLine());

                funcionarios.Add(gerente);
                Console.Clear();
                break;
            }
            else
            {
                Console.WriteLine("Digite uma opção válida");
                break;
            }
            break;

        case 3:

            Console.WriteLine("Efetuar Venda");
            Pedido pedido = new Pedido();

            Console.Write("Matricula do Funcionario: ");
            string matriculaFuncionario = Console.ReadLine();

            pedido.Funcionario = funcionarios.Find(funcionario => funcionario.Matricula == matriculaFuncionario);

            Console.Write("Quantos itens irão compor o pedido? ");
            int qtdItens = int.Parse(Console.ReadLine());

            for (int i = 0; i < qtdItens; i++)
            {
                ItemPedido item = new ItemPedido();

                Console.Write($"Id do Produto {i + 1}: ");
                int idProduto = int.Parse(Console.ReadLine());

                item.Produto = produtos.Find(produto => produto.Id == idProduto);
                item.Valor = item.Produto.Valor;

                Console.Write($"Quantidade do Produto {i + 1}: ");
                item.Quantidade = int.Parse(Console.ReadLine());

                item.SubTotal();

                pedido.AdicionaItem(item);
                Console.Clear();
            }

            pedido.DataPedido = DateTime.Now;
            pedido.Status = StatusPedido.Processando;

            pedidos.Add(pedido);
            Console.Clear();
            break;

        case 4:
            Console.WriteLine("Listar Produtos");

            produtos.ForEach(produto =>
            {
                Console.WriteLine(produto);
            }); Console.WriteLine("\n\n");

            break;

        case 5:
            Console.WriteLine("Listar Funcionarios");

            funcionarios.ForEach(func =>
            {
                Console.WriteLine(func);
            });Console.WriteLine("\n\n");

            break;

        case 6:
            Console.WriteLine("Listar Pedidos");

            pedidos.ForEach(pedido =>
            {
                Console.WriteLine(pedido);
            }); Console.WriteLine("\n\n");

            break;

        case 7:
            Console.WriteLine("Informe a matricula do funcionario: ");
            string matricula = Console.ReadLine();

            Funcionario funcionario = funcionarios.Find(func => func.Matricula == matricula);

            Console.WriteLine(funcionario.CalculaSalario(pedidos));
            Console.Clear();
            break;

        Console.ReadKey();
        Console.Clear();

    }
} while (opcao != 8);