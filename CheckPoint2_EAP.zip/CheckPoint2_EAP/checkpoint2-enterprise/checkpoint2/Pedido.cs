﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using cp2.Enums;
using cp2;

namespace cp2
{
    internal class Pedido
    {
        public int Id { get; set; }
        public DateTime DataPedido { get; set; }
        public double Valor { get; set; }

        public Funcionario Funcionario { get; set; }

        public StatusPedido Status { get; set; }

        public List<ItemPedido> Itens { get; set; }

        public void AdicionaItem(ItemPedido item)
        {
            if (Itens == null)
            {
                Itens = new List<ItemPedido>();
            }

            Itens.Add(item);
            CalculaValor();
        }

        private void CalculaValor()
        {
            double soma = 0;

            Itens.ForEach(item =>
            {
                soma += item.SubTotal();
            });

            Valor = soma;
        }

        public override string ToString()
        {
            return $"{Id} | {DataPedido} | {Valor:F2} | {Status}";
        }
    }
}
